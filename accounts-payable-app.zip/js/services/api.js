const API_URL = "https://test.requestcatcher.com";

export async function post(body) {

    const response = await fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        throw new Error(`Erro ${response.status}`);
    }

    return response.text();
}